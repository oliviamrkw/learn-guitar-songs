document.getElementById('song-request').addEventListener('submit', function(e) {
    e.preventDefault();

    // Get the songs entered by the user
    const songInput = document.getElementById('songs').value.trim();
    const songs = songInput.split(',').map(song => song.trim()).slice(0, 5);

    // Clear the results area before showing new results
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';

    // Display loading message
    resultsDiv.innerHTML = '<p>Searching for your songs...</p>';

    // Here, you'd typically make an API call to your back-end
    // But for now, we can simulate with setTimeout
    setTimeout(() => {
        // Clear loading message
        resultsDiv.innerHTML = '';

        // Simulate results (for now, these are dummy links)
        songs.forEach(song => {
            const youtubeLink = `https://www.youtube.com/results?search_query=${encodeURIComponent(song)}+guitar+lesson`;
            const tabLink = `https://www.ultimate-guitar.com/search.php?search_type=title&value=${encodeURIComponent(song)}`;

            const songResult = document.createElement('div');
            songResult.className = 'song-result';
            songResult.innerHTML = `
                <p><strong>${song}</strong></p>
                <p><a href="${youtubeLink}" target="_blank">YouTube Guitar Lesson</a></p>
                <p><a href="${tabLink}" target="_blank">Guitar Tab</a></p>
            `;
            resultsDiv.appendChild(songResult);
        });
    }, 2000); // Simulate API delay with 2 seconds
});
